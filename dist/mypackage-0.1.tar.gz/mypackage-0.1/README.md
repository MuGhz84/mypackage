# mypackage
This library was created as a example on how to publis your own Python package.

# How to install
.....